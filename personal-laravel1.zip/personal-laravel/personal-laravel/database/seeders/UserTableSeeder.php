<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;

class UserTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        User::create([
            'name' => 'abolfazl ahmadi',
            'email' => 'test@g.com',
            'password' => \Hash::make('12345678'),
            'role' => 'admin'
        ]);

        User::create([
           'name' => 'maryam',
           'email' => 'maryam@g.com',
           'password' => \Hash::make('12345678'),
        ]);

        User::create([
            'name' => 'karim mostafazadeh',
            'email' => 'mostafazadeh@g.com',
            'password' => \Hash::make('12345678'),
            'role' => 'user'
        ]);

    }
}
