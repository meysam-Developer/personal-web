<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php if(session()->has('success')): ?>
            <div class="alert alert-success text-right">
                <?php echo e(session()->get('success')); ?>

            </div>
        <?php endif; ?>
        <div class="card">
            <div class="card-header text-right">کاربران
            </div>

            <div class="card-body">
                <table class="table table-borderless text-center small">
                    <thead>
                        <tr>
                            <th>ردیف</th>
                            <th>نام</th>
                            <th>ایمیل</th>
                            <th>نقش</th>
                            <th>ویرایش</th>
                            <th>حذف</th>
                        </tr>
                    </thead>

                    <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($user->id); ?></td>
                            <td><?php echo e($user->name); ?></td>
                            <td><?php echo e($user->email); ?></td>
                            <td><?php echo e($user->role); ?></td>
                            <td>
                                <a href="<?php echo e(route('users.edit', $user->id)); ?>" class="btn btn-primary btn-sm shadow">ویرایش</a>
                            </td>
                            <td>
                                <form action="<?php echo e(route('users.destroy', $user->id)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-danger btn-sm shadow">حذف</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="alert alert-info">
                        درحال حاضر کاربری وجود ندارد
                    </div>
                    <?php endif; ?>
                    </tbody>

                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\abolfazl\Desktop\personal\resources\views/admin/users/index.blade.php ENDPATH**/ ?>