<?php if(!request()->is(['login', 'register'])): ?>
    <!-- Navbar STart -->
<header id="topnav" class="defaultscroll sticky">
    <div class="container">
        <!-- Logo container-->
        <div>
            <a class="logo" href="<?php echo e(route('index')); ?>">
                <span class="text-dark"><?php echo e(env('APP_NAME')); ?></span>
            </a>
        </div>
        <div class="buy-button">
            <?php if(auth()->guard()->check()): ?>
                <form action="<?php echo e(route('logout')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <button class="btn btn-danger" type="submit">خروج</button>
                </form>
            <?php else: ?>
                <a href="<?php echo e(route('login')); ?>">
                    <div class="btn btn-primary login-btn-primary">ورود</div>
                    <div class="btn btn-light login-btn-light">ورود</div>
                </a>
            <?php endif; ?>
        </div><!--end login button-->
        <!-- End Logo container-->
        <div class="menu-extras">
            <div class="menu-item">
                <!-- Mobile menu toggle-->
                <a class="navbar-toggle">
                    <div class="lines">
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>
                </a>
                <!-- End mobile menu toggle-->
            </div>
        </div>

        <div id="navigation">
            <!-- Navigation Menu-->
            <ul class="navigation-menu nav-light">
                <li><a href="<?php echo e(route('index')); ?>">خانه</a></li>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><a href="<?php echo e(route('category', $category->id)); ?>"><?php echo e($category->name); ?></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul><!--end navigation menu-->
            <div class="buy-menu-btn d-none">
                <?php if(auth()->guard()->check()): ?>
                    <form action="<?php echo e(route('logout')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <button class="btn btn-danger" type="submit">خروج</button>
                    </form>
                <?php else: ?>
                    <a href="<?php echo e(route('login')); ?>" class="btn btn-primary">ورود</a>
                <?php endif; ?>
            </div><!--end login button-->
        </div><!--end navigation-->
    </div><!--end container-->
</header><!--end header-->
    <!-- Navbar End -->
<?php endif; ?>
<?php /**PATH C:\Users\abolfazl\Desktop\personal\resources\views/layouts/header.blade.php ENDPATH**/ ?>