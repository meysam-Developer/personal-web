<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php if(session()->has('success')): ?>
            <div class="alert alert-success text-right">
                <?php echo e(session()->get('success')); ?>

            </div>
        <?php endif; ?>
        <div class="card">
            <div class="card-header text-right">کاربران
            </div>

            <div class="card-body">
                <table class="table table-borderless text-center small">
                    <thead>
                    <tr>
                        <th>ردیف</th>
                        <th>نام</th>
                        <th>مقاله</th>
                        <th>وضعیت</th>
                        <th>ویرایش</th>
                        <th>حذف</th>
                        <th>نمایش</th>
                    </tr>
                    </thead>

                    <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($comment->id); ?></td>
                            <td><?php echo e($comment->user->name); ?></td>
                            <td><?php echo e($comment->post->title); ?></td>
                            <td>
                                <?php if($comment->status == 0): ?>
                                    <span class="text-danger">تایید نشده</span>
                                <?php else: ?>
                                    <span class="text-success">تایید شده</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <a href="<?php echo e(route('comments.edit', $comment->id)); ?>" class="btn btn-primary btn-sm shadow">ویرایش</a>
                            </td>
                            <td>
                                <form action="<?php echo e(route('comments.destroy', $comment->id)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-danger btn-sm shadow">حذف</button>
                                </form>
                            </td>
                            <td>
                                <?php if($comment->child != null): ?>
                                <span class="btn btn-dark btn-sm shadow">پاسخ
                                        <span class="badge badge-success">-</span>
                                </span>
                                <?php else: ?>
                                    <a href="<?php echo e(route('comments.show', $comment->id)); ?>" class="btn btn-dark btn-sm shadow">پاسخ
                                    </a>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="alert alert-info">
                            درحال حاضر کاربری وجود ندارد
                        </div>
                    <?php endif; ?>
                    </tbody>

                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\abolfazl\Desktop\personal\resources\views/admin/comments/index.blade.php ENDPATH**/ ?>