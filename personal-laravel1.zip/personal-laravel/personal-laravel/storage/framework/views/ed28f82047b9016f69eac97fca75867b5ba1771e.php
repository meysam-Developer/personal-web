<?php $__env->startSection('content'); ?>
    <section class="bg-half">
        <div class="container-fluid">
            <div class="row justify-content-center">
                <div class="col-lg-10 col-md-10">
                    <div class="section-title">
                        <div class="text-center">
                            <h4 class="title mb-4"><?php echo e($post->title); ?></h4>
                            <img src="<?php echo e(asset('storage/'.$post->image)); ?>" class="img-fluid rounded-md shadow-md"
                                 alt="">
                            <div class="d-flex mt-3 align-items-center justify-content-between">
                                <p> نویسنده این مطلب : <?php echo e($post->user->name); ?> </p>
                                <p> آخرین بروزرسانی : <?php echo e($v); ?> </p>
                            </div>
                        </div>
                        <p class="text-muted">
                            <?php echo $post->description; ?>

                        </p>

                        <div>
                            <?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="<?php echo e(route('tag', $tag->id)); ?>" class="btn btn-primary btn-sm"><?php echo e($tag->name); ?></a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                        <h4 class="my-4">نظرات کاربران</h4>
                        <?php $__empty_1 = true; $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="p-4 bg-light">
                            <h6 class="text-dark"><?php echo e($comment->user->name); ?></h6>
                            <p class="text-muted h6 font-italic">
                                <?php echo e($comment->content); ?>

                            </p>

                            <?php if($comment->replies->count()): ?>
                                <?php $__currentLoopData = $comment->replies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="p-2 bg-primary rounded">
                                <h6 class="text-dark"><?php echo e($reply->user->name); ?></h6>
                                <p class="text-muted h6 font-italic">
                                    <?php echo e($reply->content); ?>

                                </p>
                            </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>

                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="alert alert-info text-right">
                                در حال حاضر نظری وجود ندارد
                            </div>
                        <?php endif; ?>

                        <?php if(auth()->guard()->check()): ?>
                            <div class="col-12 mt-3">
                                <?php if(session()->has('success')): ?>
                                    <div class="alert alert-success text-right">
                                        <?php echo e(session()->get('success')); ?>

                                    </div>
                                <?php endif; ?>
                                <form action="<?php echo e(route('comment', $post->id)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group">
                                        <textarea name="contents" cols="5" rows="5" class="form-control <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"></textarea>
                                        <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger small"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group">
                                        <button class="btn btn-success btn-sm" type="submit">ثبت نظر</button>
                                    </div>
                                </form>
                            </div>
                        <?php else: ?>
                            <div class="alert alert-info">
                                برای ارسال نظر ابتدا وارد شوید
                            </div>
                        <?php endif; ?>

                    </div>
                </div><!--end col-->
            </div><!--end row-->
        </div><!--end container-->
    </section><!--end section-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\abolfazl\Desktop\personal\resources\views/page.blade.php ENDPATH**/ ?>