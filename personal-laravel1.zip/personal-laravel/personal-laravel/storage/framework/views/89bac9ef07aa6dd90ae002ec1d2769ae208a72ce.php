<?php if(!request()->is(['login', 'register'])): ?>
    <!-- Footer Start -->
    <footer class="footer footer-bar">
        <div class="container text-center">
            <div class="row align-items-center">
                <div class="col-sm-6">
                    <div class="text-sm-left justify-content-center d-flex">
                        <p class="mb-0">طراحی شده توسط : <i class="mdi mdi-heart text-danger"></i> <a
                                href="http://www.shreethemes.in/" target="_blank" class="text-reset">mohamad_wd10@</a>
                        </p>
                    </div>
                </div><!--end col-->
            </div><!--end row-->
        </div><!--end container-->
    </footer><!--end footer-->
    <!-- Footer End -->
<?php endif; ?>
<?php /**PATH C:\Users\abolfazl\Desktop\personal\resources\views/layouts/footer.blade.php ENDPATH**/ ?>