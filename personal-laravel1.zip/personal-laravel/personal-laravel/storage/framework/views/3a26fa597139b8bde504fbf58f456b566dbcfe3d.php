<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php if(session()->has('success')): ?>
            <div class="alert alert-success text-right">
                <?php echo e(session()->get('success')); ?>

            </div>
        <?php endif; ?>
        <div class="card">
            <div class="card-header text-right">برچسب
                <a href="<?php echo e(route('tags.create')); ?>" class="btn btn-primary btn-sm float-left">ایجاد برچسب</a>
            </div>

            <div class="card-body">
                <table class="table table-borderless text-center small">
                    <thead>
                        <tr>
                            <th>ردیف</th>
                            <th>نام دسته بندی</th>
                            <th>ویرایش</th>
                            <th>حذف</th>
                        </tr>
                    </thead>

                    <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($tag->id); ?></td>
                            <td><?php echo e($tag->name); ?></td>
                            <td>
                                <a href="<?php echo e(route('tags.edit', $tag->id)); ?>" class="btn btn-primary btn-sm shadow">ویرایش</a>
                            </td>
                            <td>
                                <form action="<?php echo e(route('tags.destroy', $tag->id)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-danger btn-sm shadow">حذف</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="alert alert-info text-right">
                            برچسبی اضافه نشده است
                        </div>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\abolfazl\Desktop\personal\resources\views/admin/tags/index.blade.php ENDPATH**/ ?>