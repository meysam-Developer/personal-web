<!DOCTYPE html>
<html lang="en">
<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>

<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->yieldContent('content'); ?>

<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Back to top -->
<a href="#" class="btn btn-icon btn-soft-primary back-to-top"><i data-feather="arrow-up" class="icons"></i></a>
<!-- Back to top -->

<script src="<?php echo e(asset('files/js/jquery-3.5.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('files/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('files/js/scrollspy.min.js')); ?>"></script>
<script src="<?php echo e(asset('files/js/app.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\Users\abolfazl\Desktop\personal\resources\views/layouts/front.blade.php ENDPATH**/ ?>