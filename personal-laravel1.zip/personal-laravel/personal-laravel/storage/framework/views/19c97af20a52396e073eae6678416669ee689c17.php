<head>
    <meta charset="utf-8" />
    <title>
        <?php echo $__env->yieldContent('title'); ?>
    </title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="<?php echo e(asset('files/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('files/css/materialdesignicons.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('files/css/style-dark-rtl.css')); ?>" rel="stylesheet" type="text/css" id="theme-opt" />
</head>
<?php /**PATH C:\Users\abolfazl\Desktop\personal\resources\views/layouts/head.blade.php ENDPATH**/ ?>