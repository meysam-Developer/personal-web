<?php $__env->startSection('content'); ?>
    <!-- Hero Start -->
    <section class="bg-half w-100" style="background: url(<?php echo e(asset('files/images/landing/bg.png')); ?>) center center;">
        <div class="bg-overlay"></div>
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-12 text-center">
                    <div class="page-next-level">
                        <h4 class="title text-white title-dark"> پروژه وبسایت شخصی - دوره جامع متخصص لاراول </h4>
                        <div class="page-next">
                            <nav aria-label="breadcrumb" class="d-inline-block">
                                <ul class="breadcrumb bg-white rounded shadow mb-0">
                                    <li class="breadcrumb-item"><a href="<?php echo e(route('index')); ?>">لرن پارس</a> </li>
                                    <li class="breadcrumb-item"><a href="<?php echo e(route('index')); ?>">وبسایت شخصی</a></li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div><!--end col-->
            </div><!--end row-->
        </div> <!--end container-->
    </section><!--end section-->
    <div class="position-relative">
        <div class="shape overflow-hidden text-white">
            <svg viewBox="0 0 2880 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M0 48H1437.5H2880V0H2160C1442.5 52 720 0 720 0H0V48Z" fill="currentColor"></path>
            </svg>
        </div>
    </div>
    <!-- Hero End -->


    <section class="section">
        <div class="container">
            <div class="row">
                <?php echo $__env->make('layouts.search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div><!--end row-->

            <div class="row projects-wrapper">
                <?php $__empty_1 = true; $__currentLoopData = $category->posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col-lg-4 col-md-6 col-12 mt-4 pt-2 business">
                        <div class="card blog border-0 work-container work-classic shadow rounded-md overflow-hidden">
                            <img src="<?php echo e(asset('storage/'.$post->image)); ?>" class="img-fluid">
                            <div class="card-body">
                                <div class="content">
                                    <a href="<?php echo e(route('category', $post->category->id)); ?>" class="badge badge-primary"><?php echo e($post->category->name); ?></a>
                                    <h5 class="mt-3"><a href="<?php echo e(route('page', $post->id)); ?>" class="text-dark title"><?php echo e($post->title); ?></a></h5>
                                    <p class="text-muted">
                                        <?php echo strip_tags(Str::limit($post->description, 100)); ?>

                                    </p>
                                    <a href="<?php echo e(route('page', $post->id)); ?>" class="text-primary h6">ادامه مطلب <i data-feather="arrow-right" class="fea icon-sm"></i></a>
                                </div>
                            </div>
                        </div>
                    </div><!--end col-->
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="alert alert-info text-right">
                        در حال حاضر مقاله ای وجود ندارد
                    </div>
                <?php endif; ?>
            </div><!--end row-->
        </div><!--end container-->
    </section><!--end section-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\abolfazl\Desktop\personal\resources\views/category.blade.php ENDPATH**/ ?>