@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="card">
            <div class="card-header text-right">
                ایجاد مقاله
            </div>

            <div class="card-body text-right">
                <form action="{{ route('posts.store') }}" method="post" enctype="multipart/form-data">
                    @csrf
                    <div class="form-group">
                        <select name="category_id" class="form-control">
                            @foreach($categories as $category)
                            <option value="{{ $category->id }}">{{ $category->name }}</option>
                            @endforeach
                        </select>
                    </div>

                    <div class="form-group">
                        <select name="tags[]" class="form-control" multiple>
                            @foreach($tags as $tag)
                            <option value="{{ $tag->id }}">{{ $tag->name }}</option>
                            @endforeach
                        </select>
                    </div>

                    <div class="form-group">
                        <input type="text" class="form-control @error('title') is-invalid @enderror" placeholder="عنوان خود را وارد کنید" name="title" value="{{ old('title') }}">
                        @error('title')
                        <span class="text-danger small">{{ $message }}</span>
                        @enderror
                    </div>

                    <div class="form-group">
                        <textarea name="description" id="description" cols="4" rows="4" class="form-control @error('description') is-invalid @enderror" placeholder="متن مقاله را وارد کنید">{{ old('description') }}</textarea>
                        <script>
                            CKEDITOR.replace('description', {
                                language:'fa'
                            });
                        </script>
                        @error('description')
                        <span class="text-danger small">{{ $message }}</span>
                        @enderror
                    </div>

                    <div class="form-group">
                        <input type="file" class="form-control" name="image">
                        @error('image')
                        <span class="text-danger small">{{ $message }}</span>
                        @enderror
                    </div>

                    <div class="form-group">
                        <button type="submit" class="btn btn-success btn-sm btn-block">افزودن</button>
                    </div>

                </form>
            </div>
        </div>
    </div>
@endsection

@section('script')
    <script src="//cdn.ckeditor.com/4.16.2/full/ckeditor.js"></script>
@endsection
