@extends('layouts.app')

@section('content')
    <div class="container">
        @if(session()->has('success'))
            <div class="alert alert-success text-right">
                {{ session()->get('success') }}
            </div>
        @endif
        <div class="card">
            <div class="card-header text-right">دسته بندی
                <a href="{{ route('categories.create') }}" class="btn btn-primary btn-sm float-left">ایجاد دسته بندی</a>
            </div>

            <div class="card-body">
                <table class="table table-borderless text-center small">
                    <thead>
                        <tr>
                            <th>ردیف</th>
                            <th>نام دسته بندی</th>
                            <th>ویرایش</th>
                            <th>حذف</th>
                        </tr>
                    </thead>

                    <tbody>
                    @forelse($categories as $category)
                        <tr>
                            <td>{{ $category->id }}</td>
                            <td>{{ $category->name }}</td>
                            <td>
                                <a href="{{ route('categories.edit', $category->id) }}" class="btn btn-primary btn-sm shadow">ویرایش</a>
                            </td>
                            <td>
                                <form action="{{ route('categories.destroy', $category->id) }}" method="post">
                                    @csrf
                                    @method('DELETE')
                                    <button class="btn btn-danger btn-sm shadow">حذف</button>
                                </form>
                            </td>
                        </tr>
                    </tbody>
                    @empty
                        <div class="alert alert-info text-right">
                            در حال حاضر دسته بندی وجود ندارد
                        </div>
                    @endforelse

                </table>
            </div>
        </div>
    </div>
@endsection
