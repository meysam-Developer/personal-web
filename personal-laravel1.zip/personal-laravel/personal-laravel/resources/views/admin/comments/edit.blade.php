@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="card">
            <div class="card-header text-right">
                ویرایش نظر
            </div>

            <div class="card-body text-right">
                <form action="{{ route('comments.update', $comment->id) }}" method="post">
                    @csrf
                    @method('PUT')
                    <div class="form-group">
                        <input type="text" class="form-control" value="{{ $comment->user->name }}" disabled>
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control" value="{{ $comment->post->title }}" disabled>
                    </div>
                    <div class="form-group">
                        <textarea name="contents" cols="30" rows="10" class="form-control @error('content') is-invalid @enderror">{{ $comment->content }}</textarea>
                        @error('content')
                        <span class="text-danger small">{{ $message }}</span>
                        @enderror
                    </div>
                    <div class="form-group">
                        <input type="text" name="status" class="form-control @error('status') is-invalid @enderror" value="{{ $comment->status }}">
                        @error('status')
                        <span class="text-danger small">{{ $message }}</span>
                        @enderror
                    </div>

                    <div class="form-group">
                        <button type="submit" class="btn btn-success btn-sm btn-block">ویرایش</button>
                    </div>

                </form>
            </div>
        </div>
    </div>
@endsection
