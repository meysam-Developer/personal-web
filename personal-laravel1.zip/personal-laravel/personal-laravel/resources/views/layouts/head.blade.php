<head>
    <meta charset="utf-8" />
    <title>
        @yield('title')
    </title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="{{ asset('files/css/bootstrap.min.css') }}" rel="stylesheet" type="text/css" />
    <link href="{{ asset('files/css/materialdesignicons.min.css') }}" rel="stylesheet" type="text/css" />
    <link href="{{ asset('files/css/style-dark-rtl.css') }}" rel="stylesheet" type="text/css" id="theme-opt" />
</head>
