<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Testing\Fluent\Concerns\Has;
use Laravel\Socialite\Facades\Socialite;

class GoogleController extends Controller
{
    public function next()
    {
        return Socialite::driver('google')->redirect();
    }

    public function handleCallback()
    {
        $user = Socialite::driver('google')->stateless()->user();
//        dd($user);
        $siteUser = User::where('email', $user->email)->first();
        if ($siteUser){
            Auth::loginUsingId($siteUser->id);
            return redirect(route('index'));
        }else{
            $newUser = User::create([
                'name' => $user->name,
                'email' => $user->email,
                'password' => Hash::make('12345678')
            ]);

            if ($newUser){
                $newUser->email_verified_at = now();
                $newUser->save();
            }

            Auth::loginUsingId($newUser->id);
            return redirect(route('index'));
        }
    }
}
